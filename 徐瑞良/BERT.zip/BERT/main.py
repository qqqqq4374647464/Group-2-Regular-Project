import os
# 配置 HuggingFace 国内镜像，加速下载
os.environ["HF_ENDPOINT"] = "https://hf-mirror.com"
import torch
from torch.utils.data import DataLoader
from FCModel import FCModel  # 自定义全连接层模型
from MRPCDataset import MRPCDataset  # 自定义MRPC数据集
from transformers import BertTokenizer, BertModel  # HuggingFace BERT组件

# 设置随机种子以保证结果可复现
torch.manual_seed(42)
if torch.cuda.is_available():
    torch.cuda.manual_seed_all(42)

def main():
    # 1. 数据加载与预处理（指定 collate_fn）
    try:
        mrpc_dataset = MRPCDataset()
        train_loader = DataLoader(
            dataset=mrpc_dataset,
            batch_size=16,
            shuffle=True,
            pin_memory=True,
            collate_fn=MRPCDataset.collate_fn  # 关键：使用Dataset定义的collate_fn
        )
        print(f"数据载入完成，训练集批次数量: {len(train_loader)}")
    except Exception as e:
        print(f"数据加载失败: {str(e)}")
        return

    # 2. 设备配置
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"使用设备: {device}")
    if device.type == 'cuda':
        print(f"GPU型号: {torch.cuda.get_device_name(0)}")

    # 3. 加载BERT模型与分词器
    try:
        tokenizer = BertTokenizer.from_pretrained("bert-base-uncased")
        bert_model = BertModel.from_pretrained("bert-base-uncased")
        bert_model.to(device)
        print("BERT模型加载完成")
    except Exception as e:
        print(f"BERT模型加载失败: {str(e)}")
        return

    # 4. 创建全连接层模型
    model = FCModel().to(device)
    print("全连接层模型创建完成")

    # 5. 定义优化器与损失函数（BERT微调学习率2e-5，全连接层1e-4）
    optimizer = torch.optim.Adam(model.parameters(), lr=1e-4)
    bert_optimizer = torch.optim.Adam(bert_model.parameters(), lr=2e-5)
    criterion = torch.nn.BCELoss()

    # 6. 准确率计算函数
    def binary_accuracy(predictions, labels):
        """计算二分类任务的准确率"""
        rounded_preds = torch.round(predictions)
        correct = (rounded_preds == labels).float()
        return correct.sum() / len(correct)

    # 7. 训练函数（核心适配Dataset格式）
    def train_epoch():
        bert_model.train()
        model.train()
        
        total_loss = 0.0
        total_acc = 0.0
        total_samples = 0

        # 适配Dataset输出：(句子对列表, 标签张量)
        for batch_idx, (sentence_tuples, labels) in enumerate(train_loader):
            # 解压句子对列表：[(sent1,sent2), ...] → sentence1列表 + sentence2列表
            sentence1, sentence2 = zip(*sentence_tuples)
            sentence1 = list(sentence1)
            sentence2 = list(sentence2)

            # 标签移动到设备并转float32（匹配BCELoss要求）
            labels = labels.to(device, dtype=torch.float32)
            
            # 内存使用监控（每10个batch打印）
            if batch_idx % 10 == 0 and device.type == 'cuda':
                mem_used = torch.cuda.memory_allocated() / 1024**2
                print(f"Batch {batch_idx} 内存使用: {mem_used:.2f} MB")

            # BERT编码（传入句子对 text + text_pair）
            encoding = tokenizer(
                text=sentence1,
                text_pair=sentence2,
                return_tensors='pt',
                padding=True,
                truncation=True,
                max_length=128
            ).to(device)
            
            # 若微调BERT，删除with torch.no_grad()
            with torch.no_grad():
                bert_output = bert_model(**encoding)
                pooler_output = bert_output.pooler_output  # [batch_size, 768]

            # 模型预测与维度适配
            predictions = model(pooler_output).squeeze(dim=-1)
            # 处理单样本batch（最后一个batch可能只有1条数据）
            if predictions.dim() == 0:
                predictions = predictions.unsqueeze(0)

            # 计算损失与准确率
            loss = criterion(predictions, labels)
            acc = binary_accuracy(predictions, labels)

            # 反向传播与参数更新（梯度裁剪防爆炸）
            optimizer.zero_grad()
            bert_optimizer.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(bert_model.parameters(), max_norm=1.0)
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
            optimizer.step()
            bert_optimizer.step()

            # 累计统计
            batch_size = labels.size(0)
            total_loss += loss.item() * batch_size
            total_acc += acc.item() * batch_size
            total_samples += batch_size

            # 打印批次信息
            if batch_idx % 10 == 0:
                print(f"Batch {batch_idx}/{len(train_loader)} - 损失: {loss.item():.4f}, 准确率: {acc.item():.4f}")

        # 计算平均指标
        avg_loss = total_loss / total_samples
        avg_acc = total_acc / total_samples
        return avg_loss, avg_acc

    # 8. 开始训练
    num_epochs = 3  # 训练3个epoch，可根据效果调整
    print(f"\n开始训练，共 {num_epochs} 个epoch")
    for epoch in range(num_epochs):
        epoch_loss, epoch_acc = train_epoch()
        print(f"\nEpoch {epoch+1}/{num_epochs} - 平均损失: {epoch_loss:.4f}, 平均准确率: {epoch_acc:.4f}\n")

    # 清理GPU内存
    if device.type == 'cuda':
        torch.cuda.empty_cache()
    print("训练完成！")

if __name__ == "__main__":
    main()