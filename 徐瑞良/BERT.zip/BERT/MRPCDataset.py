# MRPCDataset.py
import os
import torch
from torch.utils.data import Dataset

class MRPCDataset(Dataset):
    def __init__(self, data_dir="./data", split="train"):
        """
        初始化MRPC数据集
        :param data_dir: 数据存放目录（含train.txt和test.txt）
        :param split: 数据集类型，"train"或"test"
        """
        self.data_dir = data_dir
        self.split = split
        self.sentence_pairs = []  # 存储句子对：[(sent1, sent2), ...]
        self.labels = []          # 存储标签：[1, 0, ...]
        self._load_data()

    def _load_data(self):
        """加载并解析MRPC的train.txt或test.txt"""
        # 拼接数据文件路径
        file_path = os.path.join(self.data_dir, f"{self.split}.txt")
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"未找到数据文件：{file_path}，请检查路径是否正确")

        # 读取文件（跳过首行表头）
        with open(file_path, "r", encoding="utf-8") as f:
            lines = f.readlines()[1:]  # 首行是表头，跳过

        # 解析每行数据
        for line in lines:
            line = line.strip()
            if not line:
                continue  # 跳过空行
            # 按\t分割（格式：Quality\t#1 ID\t#2 ID\t#1 String\t#2 String）
            parts = line.split("\t")
            if len(parts) < 5:
                continue  # 跳过格式错误的行
            label = int(parts[0])       # 标签（0或1）
            sent1 = parts[3].strip()    # 第一个句子
            sent2 = parts[4].strip()    # 第二个句子
            self.sentence_pairs.append((sent1, sent2))
            self.labels.append(label)

        print(f"成功加载{self.split}集：{len(self.labels)}条数据")

    def __len__(self):
        """返回数据集大小"""
        return len(self.labels)

    def __getitem__(self, idx):
        """根据索引返回数据：(句子对, 标签)"""
        sent1, sent2 = self.sentence_pairs[idx]
        label = self.labels[idx]
        # 返回格式：((sent1, sent2), label)，方便后续分词处理
        return (sent1, sent2), label

    @staticmethod
    def collate_fn(batch):
        """
        DataLoader的collate_fn：将多个样本整理成批次数据
        :param batch: 列表，每个元素是__getitem__的返回值：((sent1, sent2), label)
        :return: 句子对列表、标签张量
        """
        sentences = []  # 存储所有句子对，格式：[(sent1, sent2), ...]
        labels = []     # 存储标签
        for (sents, label) in batch:
            sentences.append(sents)
            labels.append(label)
        # 标签转换为Tensor
        labels = torch.tensor(labels, dtype=torch.long)
        return sentences, labels