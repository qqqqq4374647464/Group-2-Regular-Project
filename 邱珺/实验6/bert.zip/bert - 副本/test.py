import torch
print(torch.__version__)        # 应该是 1.7.0
print(torch.cuda.is_available()) # True 表示可以使用 GPU
print(torch.version.cuda)       # 输出 CUDA 版本
