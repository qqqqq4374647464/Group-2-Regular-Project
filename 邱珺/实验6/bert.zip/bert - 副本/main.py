# main.py
import os
import torch
from torch.utils.data import DataLoader
from FCModel import FCModel
from MRPCDataset import MRPCDataset
from transformers import BertTokenizer, BertModel

# 1. 加载MRPC训练数据集（句子对数据）
# 注意：MRPCDataset默认加载train集，数据目录为./data
mrpc_dataset = MRPCDataset(split="train")
# 使用自定义的collate_fn处理批次数据（适配句子对格式）
train_loader = DataLoader(
    dataset=mrpc_dataset,
    batch_size=16,
    shuffle=True,
    collate_fn=MRPCDataset.collate_fn  # 关键：用数据集自带的整理函数
)
print("数据载入完成（句子对格式）")

# 2. 配置运行设备（支持CUDA/MPS/CPU）
device = torch.device(
    'cuda' if torch.cuda.is_available() else
    'mps' if torch.backends.mps.is_available() else
    'cpu'
)
print(f"使用设备: {device}")

# 尝试在所选 device 上分配一个小张量以验证 CUDA 可用性是否真的可用（避免因 CUDA 架构不匹配导致后续运行失败）
def _verify_device(dev):
    try:
        t = torch.tensor([0.0], device=dev)
        # 如果是 CUDA，尝试读取设备名称以触发可能的驱动/兼容性错误
        if str(dev).startswith('cuda'):
            try:
                _ = torch.cuda.get_device_name(t.device)
            except Exception:
                # ignore inner error, higher-level except will catch
                pass
        return True
    except Exception as e:
        print(f"警告：无法在设备 {dev} 上分配张量，回退到 CPU。错误: {e}")
        return False

if not _verify_device(device):
    device = torch.device('cpu')
    print("已切换到设备: cpu")

# 3. 加载BERT模型和分词器（适配句子对任务）
# 强制 transformers 离线模式，避免在无网络/代理问题下尝试联网
os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")
model_dir = os.path.join(os.path.dirname(__file__), "model")

# 检查本地 model 目录及必要文件，若缺失则直接退出，避免联网下载失败导致的异常链
required_files = [
    os.path.join(model_dir, "config.json"),
    os.path.join(model_dir, "pytorch_model.bin"),
]
# tokenizer 可能使用 vocab.txt 或 tokenizer.json，两者任选其一即可
tokenizer_files = [
    os.path.join(model_dir, "vocab.txt"),
    os.path.join(model_dir, "tokenizer.json"),
]

missing = [p for p in required_files if not os.path.exists(p)]
token_ok = any(os.path.exists(p) for p in tokenizer_files)
if not os.path.isdir(model_dir) or missing or not token_ok:
    msg_lines = [f"无法离线加载本地模型 (目录={model_dir})。请确保以下文件存在："]
    for p in required_files:
        msg_lines.append(f"  - {os.path.basename(p)}: {'存在' if os.path.exists(p) else '缺失'}")
    msg_lines.append(f"并且至少包含 tokenizer 文件之一: {', '.join([os.path.basename(p) for p in tokenizer_files])}")
    # 列出当前 model 目录下的文件以供用户参考
    if os.path.isdir(model_dir):
        try:
            files = os.listdir(model_dir)
            msg_lines.append("当前 model 目录内容: " + ", ".join(files) if files else "(空目录)")
        except Exception:
            msg_lines.append("无法读取 model 目录内容")
    else:
        msg_lines.append("model 目录不存在")

    msg_lines.append("")
    msg_lines.append("解决方法示例：在能联网的环境运行以下代码一次以保存模型到本地：")
    msg_lines.append("  from transformers import BertModel, BertTokenizer")
    msg_lines.append("  tokenizer = BertTokenizer.from_pretrained('bert-base-uncased')")
    msg_lines.append("  model = BertModel.from_pretrained('bert-base-uncased')")
    msg_lines.append("  tokenizer.save_pretrained('./model')")
    msg_lines.append("  model.save_pretrained('./model')")

    raise SystemExit("\n".join(msg_lines))

# 本地文件齐全时直接加载（local_files_only=True 确保不会联网）
tokenizer = BertTokenizer.from_pretrained(model_dir, local_files_only=True)
bert_model = BertModel.from_pretrained(model_dir, local_files_only=True)
# 将模型移至设备，若移动失败则回退到 CPU
try:
    bert_model.to(device)
except Exception as e:
    print(f"警告：将 BERT 模型移至设备 {device} 失败: {e}\n回退到 CPU 来继续运行。")
    device = torch.device('cpu')
    bert_model.to(device)

print(f"已从本地加载 BERT 模型：{model_dir} (当前设备: {device})")

# 4. 初始化全连接分类模型（接收BERT输出）
model = FCModel()
try:
    model.to(device)
except Exception as e:
    print(f"警告：将自定义分类器移至设备 {device} 失败: {e}\n回退到 CPU。")
    device = torch.device('cpu')
    model.to(device)
print("全连接分类模型创建完成")

# 5. 定义优化器（BERT学习率通常远小于分类头）
# 经验值：BERT用2e-5，分类头用1e-3，避免预训练参数被破坏
optimizer = torch.optim.Adam(model.parameters(), lr=1e-3)
bert_optimizer = torch.optim.Adam(bert_model.parameters(), lr=2e-5)
criterion = torch.nn.BCELoss()  # 二分类损失（适用于0/1标签）

# 6. 计算二分类准确率
def binary_accuracy(predict, label):
    rounded_predict = torch.round(predict)  # 四舍五入为0或1
    correct = (rounded_predict == label).float()
    return correct.sum() / len(correct)

# 7. 训练函数（适配句子对输入）
def train():
    epoch_loss, epoch_acc = 0.0, 0.0
    total_samples = 0

    for batch_idx, (sentence_pairs, labels) in enumerate(train_loader):
        # 切换训练模式
        bert_model.train()
        model.train()

        # 标签移至设备
        labels = labels.to(device)

        # 解析句子对：分离sent1和sent2列表
        sent1_list = [pair[0] for pair in sentence_pairs]
        sent2_list = [pair[1] for pair in sentence_pairs]

        # BERT分词器处理句子对（自动拼接为"[CLS] sent1 [SEP] sent2 [SEP]"）
        encoding = tokenizer(
            sent1_list,
            sent2_list,
            return_tensors="pt",
            padding=True,
            truncation=True,
            max_length=128  # 限制最大长度，避免显存溢出
        )
        # 编码结果移至设备
        encoding = {k: v.to(device) for k, v in encoding.items()}

        # BERT前向传播：获取[CLS]池化输出
        bert_output = bert_model(** encoding)
        pooler_output = bert_output.pooler_output  # shape: (batch_size, 768)

        # 全连接层预测（输出概率）
        predict = model(pooler_output).squeeze()  # 压缩为(batch_size,)

        # 计算损失和准确率
        loss = criterion(predict, labels.float())  # BCELoss要求标签为float
        acc = binary_accuracy(predict, labels)

        # 梯度清零+反向传播+参数更新
        optimizer.zero_grad()
        bert_optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        bert_optimizer.step()

        # 累计统计
        batch_size = len(labels)
        epoch_loss += loss.item() * batch_size
        epoch_acc += acc.item() * batch_size
        total_samples += batch_size

        # 打印批次信息（每10个batch打印一次，避免刷屏）
        if (batch_idx + 1) % 10 == 0:
            print(f"batch {batch_idx+1} | loss: {loss.item():.4f} | acc: {acc.item():.4f}")

    # 返回平均损失和准确率
    return epoch_loss / total_samples, epoch_acc / total_samples

# 8. 开始训练（可调整epoch数）
num_epochs = 8  # 建议至少训练3-5个epoch观察效果
for epoch in range(num_epochs):
    print(f"\n===== Epoch {epoch+1}/{num_epochs} =====")
    avg_loss, avg_acc = train()
    print(f"Epoch {epoch+1} 结束 | 平均损失: {avg_loss:.4f} | 平均准确率: {avg_acc:.4f}")

print("训练完成！")