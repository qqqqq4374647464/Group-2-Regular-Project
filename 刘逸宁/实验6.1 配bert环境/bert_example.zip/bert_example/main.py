import torch
from torch.utils.data import DataLoader
from FCModel import FCModel
from MRPCDataset import MRPCDataset
from transformers import BertTokenizer, BertModel

# 1. 加载MRPC训练数据集（句子对数据）
# 注意：MRPCDataset默认加载train集，数据目录为./data
mrpc_dataset = MRPCDataset(split="train")
# 使用自定义的collate_fn处理批次数据（适配句子对格式）
train_loader = DataLoader(
    dataset=mrpc_dataset,
    batch_size=16,
    shuffle=True,
    collate_fn=MRPCDataset.collate_fn  # 关键：用数据集自带的整理函数
)
print("数据载入完成（句子对格式）")

# 2. 配置运行设备（支持CUDA/MPS/CPU）
device = torch.device(
    'cuda' if torch.cuda.is_available() else
    'mps' if torch.backends.mps.is_available() else
    'cpu'
)
print(f"使用设备: {device}")

# 3. 加载BERT模型和分词器（适配句子对任务）
tokenizer = BertTokenizer.from_pretrained("bert-base-uncased")
bert_model = BertModel.from_pretrained("bert-base-uncased")
bert_model.to(device)
print("BERT模型加载完成（base-uncased）")

# 4. 初始化全连接分类模型（接收BERT输出）
model = FCModel()
model.to(device)
print("全连接分类模型创建完成")

# 5. 定义优化器（BERT学习率通常远小于分类头）
# 经验值：BERT用2e-5，分类头用1e-3，避免预训练参数被破坏
optimizer = torch.optim.Adam(model.parameters(), lr=1e-3)
bert_optimizer = torch.optim.Adam(bert_model.parameters(), lr=2e-5)
criterion = torch.nn.BCELoss()  # 二分类损失（适用于0/1标签）

# 6. 计算二分类准确率
def binary_accuracy(predict, label):
    rounded_predict = torch.round(predict)  # 四舍五入为0或1
    correct = (rounded_predict == label).float()
    return correct.sum() / len(correct)

# 7. 训练函数（适配句子对输入）
def train():
    epoch_loss, epoch_acc = 0.0, 0.0
    total_samples = 0

    for batch_idx, (sentence_pairs, labels) in enumerate(train_loader):
        # 切换训练模式
        bert_model.train()
        model.train()

        # 标签移至设备
        labels = labels.to(device)

        # 解析句子对：分离sent1和sent2列表
        sent1_list = [pair[0] for pair in sentence_pairs]
        sent2_list = [pair[1] for pair in sentence_pairs]

        # BERT分词器处理句子对（自动拼接为"[CLS] sent1 [SEP] sent2 [SEP]"）
        encoding = tokenizer(
            sent1_list,
            sent2_list,
            return_tensors="pt",
            padding=True,
            truncation=True,
            max_length=128  # 限制最大长度，避免显存溢出
        )
        # 编码结果移至设备
        encoding = {k: v.to(device) for k, v in encoding.items()}

        # BERT前向传播：获取[CLS]池化输出
        bert_output = bert_model(** encoding)
        pooler_output = bert_output.pooler_output  # shape: (batch_size, 768)

        # 全连接层预测（输出概率）
        predict = model(pooler_output).squeeze()  # 压缩为(batch_size,)

        # 计算损失和准确率
        loss = criterion(predict, labels.float())  # BCELoss要求标签为float
        acc = binary_accuracy(predict, labels)

        # 梯度清零+反向传播+参数更新
        optimizer.zero_grad()
        bert_optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        bert_optimizer.step()

        # 累计统计
        batch_size = len(labels)
        epoch_loss += loss.item() * batch_size
        epoch_acc += acc.item() * batch_size
        total_samples += batch_size

        # 打印批次信息（每10个batch打印一次，避免刷屏）
        if (batch_idx + 1) % 10 == 0:
            print(f"batch {batch_idx+1} | loss: {loss.item():.4f} | acc: {acc.item():.4f}")

    # 返回平均损失和准确率
    return epoch_loss / total_samples, epoch_acc / total_samples

# 8. 开始训练（可调整epoch数）
num_epochs = 8  # 建议至少训练3-5个epoch观察效果
for epoch in range(num_epochs):
    print(f"\n===== Epoch {epoch+1}/{num_epochs} =====")
    avg_loss, avg_acc = train()
    print(f"Epoch {epoch+1} 结束 | 平均损失: {avg_loss:.4f} | 平均准确率: {avg_acc:.4f}")

print("训练完成！")